﻿using System;
using System.Windows.Forms;

namespace EasyBank_Management_System
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Start the application from the first point in the flow!
            Application.Run(new frmWelcome());
            // OR
            // Application.Run(new frmCreateANewAccountStep1()); 
        }
    }
}