﻿using System;
using System.Windows.Forms;

namespace EasyBank_Management_System
{
   
    public partial class frmCreateANewAccountStep3 : Form
    {
        // This reference is now guaranteed not to be null when btnBack_Click runs.
      
       private frmCreateANewAccountStep2 _step2Form;
       
        private string _email, _phoneNumber, _nationalIdOrCIF;

        // Constructor called from Step2
        public frmCreateANewAccountStep3(frmCreateANewAccountStep2 step2Form, string email, string phoneNumber, string nationalIdOrCIF)
        {
            InitializeComponent();

            // ✅ Save reference of Step2 form
            _step2Form = step2Form ?? throw new ArgumentNullException(nameof(step2Form));

            _email = email;
            _phoneNumber = phoneNumber;
            _nationalIdOrCIF = nationalIdOrCIF;
        }


        // ✅ Called from Step2 (if returning)
        public void SetPreviousData(string username, string password, string confirmPass)
        {
            txtUsername.Text = username;
            txtPassword.Text = password;
            txtConfirmPassword.Text = confirmPass;
        }


        private void btnBack_Click(object sender, EventArgs e)
        {
            // 1. Save data from Step3 before going back
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            string confirmPass = txtConfirmPassword.Text;
            if (_step2Form != null)
            {
                _step2Form.Show();
                this.Hide();
            }
            else
            {
                // This should not happen if Step 2's btnNext_Click is correct.
                MessageBox.Show("Cannot go back. Reference to Step 2 is missing.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


        private void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;
            string confirmPass = txtConfirmPassword.Text;

            // ✅ Validation
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Username and Password are required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (password != confirmPass)
            {
                MessageBox.Show("Passwords do not match.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!chkAgree.Checked)
            {
                MessageBox.Show("You must accept the terms and conditions.", "Agreement Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // ✅ Move to dashboard or next form
            frmDashboard formDashboard = new frmDashboard();
            formDashboard.Show();
            this.Hide();
        }
    }
}