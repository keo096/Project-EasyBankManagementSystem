﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EasyBank_Management_System
{
    public partial class frmSplashScreen : Form
    {
        Timer timer;
        public frmSplashScreen()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            timer.Stop();
            frmWelcome fromWelcome = new frmWelcome();
            fromWelcome.Show();
            this.Hide();
        }

        private void frmSplashScreen_Load(object sender, EventArgs e)
        {
            timer = new Timer();
            timer.Interval = 2000;
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void frmSplashScreen_Load_1(object sender, EventArgs e)
        {

        }
    }
}
