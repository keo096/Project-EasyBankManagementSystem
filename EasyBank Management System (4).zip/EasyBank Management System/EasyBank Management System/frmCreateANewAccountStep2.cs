﻿using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace EasyBank_Management_System
{
    public partial class frmCreateANewAccountStep2 : Form
    {
        private frmCreateANewAccountStep1 _step1Form;
        private frmCreateANewAccountStep3 _step3Form;
     


        // Fields from Step1
        private string _firstName;
        private string _lastName;
        private string _gender;
        private DateTime _dob;
       
        // Constructor called from Step1
        public frmCreateANewAccountStep2(frmCreateANewAccountStep1 step1Form, string firstName, string lastName, string gender, DateTime dob)
        {
            InitializeComponent();
            _step1Form = step1Form ?? throw new ArgumentNullException(nameof(step1Form));
            _firstName = firstName;
            _lastName = lastName;
            _gender = gender;
            _dob = dob;
        }

        // ✅ Set previous Step2 data when coming back from Step3
        public void SetPreviousData(string email, string phoneNumber, string nationalIDOrCIF)
        {
            txtEmail.Text = email;
            txtPhoneNumber.Text = phoneNumber;
            txtNationalIdOrCIF.Text = nationalIDOrCIF;
        }

        private void frmCreateANewAccountStep2_Load(object sender, EventArgs e)
        {
            // Optional initialization if needed
        }

        // ✅ Back button returns to Step1
        private void btnBack_Click(object sender, EventArgs e)
        {
            if (_step1Form != null)
            {
                _step1Form.SetPreviousData(_firstName, _lastName, _gender, _dob);
                _step1Form.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Previous form not found. Please restart the process.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ✅ Email validation
        private bool IsValidEmail(string email)
        {
            string pattern = @"^[a-z0-9._]+@(gmail\.com|yahoo\.com|outlook\.com)$";
            return Regex.IsMatch(email, pattern);
        }

        // ✅ Next button moves to Step3 (FIXED LOGIC)
        // Inside frmCreateANewAccountStep2.cs

        private void btnNext_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text.Trim();
            string phoneNumber = txtPhoneNumber.Text.Trim();
            string nationalIDOrCIF = txtNationalIdOrCIF.Text.Trim();

            // 1. **REQUIRED VALIDATION BEFORE CREATING STEP 3**
            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(phoneNumber) || string.IsNullOrWhiteSpace(nationalIDOrCIF))
            {
                MessageBox.Show("All fields are required in Step 2.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // <--- MUST EXIT HERE
            }

            if (!IsValidEmail(email))
            {
                MessageBox.Show("Please enter a valid email address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // <--- MUST EXIT HERE
            }

            // 2. ONLY proceed if validation is passed
            // We will *always* create a new Step 3 instance here to ensure fresh data is passed,
            // which simplifies form management and guarantees the constructor runs.

            // ✅ PASSING 'this' ENSURES _step2Form IS SET IN STEP 3!
            frmCreateANewAccountStep3 step3Form = new frmCreateANewAccountStep3(
                this, // <--- CRITICAL: 'this' is the Step 2 form instance
                email,
                phoneNumber,
                nationalIDOrCIF
            );

            step3Form.Show();
            this.Hide();

            // **OPTIONAL: Clean up the old _step3Form reference**
            // If you keep the `_step3Form` field, you should update it:
            _step3Form = step3Form;
        }
    }
}